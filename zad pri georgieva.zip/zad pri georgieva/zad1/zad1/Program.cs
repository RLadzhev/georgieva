﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Point<int> point = new Point<int>(3, 4);

            Console.WriteLine(point);
            point.Swap();
            Console.WriteLine(point);
        }
    }
}

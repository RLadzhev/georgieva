﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Point> krusha = new List<Point>
            {
                new Point(2, 5), new Point(3, 7), new Point(4, 9),
                new Point(5, 10), new Point(6, 9), new Point(7, 7),
                new Point(8, 5), new Point(7, 4), new Point(6, 3),
                new Point(4, 2), new Point(3, 3)
            };

            Point midpoint = Point.Midpoint(krusha);

            Console.WriteLine($"Sredna tochka= ({midpoint.X}, {midpoint.Y})");
        }
    }
}

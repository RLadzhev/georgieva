﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    public class Point
    {
        private int x;
        private int y;
        public int X
        {
            get {return x;}
            set {x = value;}
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
        public static Point Midpoint(List<Point> points)
        {
            double sumX = 0;
            double sumY = 0;

            foreach (var point in points)
            {
                sumX += point.X;
                sumY += point.Y;
            }

            int midX = (int)(sumX / points.Count);
            int midY = (int)(sumY / points.Count);

            return new Point(midX, midY);
        }
    }
}


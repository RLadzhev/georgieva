﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Point<int> point1 = new Point<int>(1,2);
            Point<int> point2 = new Point<int>(4,6);

            double distance = point1.DistanceTo(point2);

            Console.WriteLine("Разстоянието е:"+distance);
        }
    }
}
